# CO PO Mapping Automation Project

Members:
<ul>
<li>Arul Prasath V (Arch.)</li>
<li>Gowthamkrishnan S (Facilitator)</li>
<li>Deepti R (Backend Engineer)</li>
</ul><br/>
Mentorship:
<ul>
  <li>Abinash S</li>
 <li>Ajay R</li>
</ul>
