---
name: Support Question
about: Use this if you have a any question or need a helping hand
title: "[Help] summary of your issue"
labels: state/awaiting-triage, type/usage
assignees: ''

---

# Help Wanted
<!-- Tell us your question or what you need help with. (required) -->

## Testcase
<!--
  If your asking for help please include an example of your problem to help
  us provide the best support.

  How to create an example:
   1. Open the following JSFiddle - https://jsfiddle.net/31d6y7mn
   2. Click "Fork" at the top
   3. Add the minimum required HTML, CSS and JavaScript which reproduces
      your problem
   4. Click "Save" at the top
   5. Copy the URL of your fiddle and link it here
-->
